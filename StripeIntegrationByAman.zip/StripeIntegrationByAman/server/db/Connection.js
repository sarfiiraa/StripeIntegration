import mongoose from "mongoose";
const ConnectionString =
  process.env.MONGO_URI ||
  "mongodb+srv://fsrz4:GIKl6btB9S3FqG2p@cluster0.b4yzr.mongodb.net/";
const connectDB = async () => {
  try {
    const conection= await mongoose.connect(ConnectionString);
    console.log("MongoDB connected..."+conection.connection.host+", "+conection.connection.name+", "+conection.connection.port);
  } catch (error) {
    console.error("Error connecting to MongoDB:", error);
    process.exit(1);
  }
};

export default connectDB;
