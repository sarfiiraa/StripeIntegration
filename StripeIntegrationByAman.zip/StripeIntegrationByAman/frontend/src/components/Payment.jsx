import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import {
  useStripe,
  useElements,
  PaymentElement,
} from "@stripe/react-stripe-js";
import axios from "axios";

const Payment = () => {
  const stripe = useStripe();
  const elements = useElements();
  const navigate = useNavigate();
  const { state } = useLocation();

  // Fetch clientSecret from localStorage or location state
  const [clientSecret, setClientSecret] = useState(
    state?.clientSecret || localStorage.getItem("secret") || ""
  );
  const [errorMessage, setErrorMessage] = useState("");

  const email=localStorage.getItem("email");

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    if (!stripe || !elements || !clientSecret) {
      setErrorMessage("Stripe or Elements are not fully loaded.");
      return;
    }
  
    // Trigger form validation and wallet collection
    const { error: submitError } = await elements.submit();
  
    // If there is an error in submitting the form, show it to the user
    if (submitError?.message) {
      setErrorMessage(submitError.message);
      return;
    }
  
    // Proceed with payment after form validation is successful
    const { error } = await stripe.confirmPayment({
      elements,
      clientSecret,
      confirmParams: {
        return_url: "http://localhost:5173/success", // Replace with your success page URL
      },
    });
  
    if (error) {
      console.error("Payment failed:", error.message);
      setErrorMessage(`Payment failed: ${error.message}`);
    } else {
      // alert("Payment successful!");
      
      try{
        const response = await axios.patch('http://localhost:3001/api/order/updateOrder', {
          email:email
        });
      }  catch (error) {
      console.error("Error updating payment status:", error);
      setErrorMessage("An error occurred while updating payment status.");
    }
      navigate("/");
    }
  };
  

  if (!clientSecret || !stripe || !elements) {
    return <div>Loading payment details...</div>;
  }

  return (
    <form onSubmit={handleSubmit} className="p-4">
      <h2 className="text-xl font-bold mb-4">Complete Payment</h2>
      <PaymentElement />
      <button
        type="submit"
        disabled={!stripe || !elements || !clientSecret}
        className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
      >
        Pay Now
      </button>
      {errorMessage && <div className="text-red-500 mt-4">{errorMessage}</div>}
    </form>
  );
};

export default Payment;
