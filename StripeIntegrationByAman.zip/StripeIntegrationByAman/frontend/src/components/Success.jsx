// import axios from 'axios'
// import React, { useEffect } from 'react'

// const Success = () => {

  
//   return (
//     <div>Thank You</div>
//   )
// }

// export default Success

import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const Success = () => {
  const navigate = useNavigate();

  // Redirect to the home page after a few seconds, you can adjust the time as needed
  useEffect(() => {
    setTimeout(() => {
      navigate('/');
    }, 5000); // Redirect after 5 seconds
  }, [navigate]);

  return (
    <div className="flex justify-center items-center min-h-screen bg-gradient-to-r from-green-400 via-blue-500 to-purple-600">
      <div className="bg-white p-10 rounded-lg shadow-lg text-center max-w-md w-full">
        <h1 className="text-4xl font-semibold text-green-600 mb-4">Payment Successful!</h1>
        <p className="text-lg text-gray-700 mb-6">
          Thank you for your purchase. We appreciate your business.
        </p>
        <div className="text-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-green-500 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
          </svg>
          <p className="text-lg text-gray-500 mb-6">Your order is being processed.</p>
        </div>

        <button
          onClick={() => navigate('/')}
          className="px-6 py-3 text-white bg-green-600 hover:bg-green-700 rounded-md transition duration-300 ease-in-out"
        >
          Back to Home
        </button>
      </div>
    </div>
  );
};

export default Success;
