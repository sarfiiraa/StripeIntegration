import React from 'react'

export const Failure = () => {
  return (
    <div>Payment Failed</div>
  )
}
