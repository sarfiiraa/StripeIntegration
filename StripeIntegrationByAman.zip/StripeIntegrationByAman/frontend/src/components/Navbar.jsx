import React, { useContext } from "react";
import { CiShoppingCart } from "react-icons/ci";
import { useNavigate } from "react-router-dom";
import { CartContext } from "../context/cart";

export const Navbar = () => {
  const { cartItems } = useContext(CartContext);
  let items = 0;
  for (let i = 0; i < cartItems?.length; i++) {
    items += cartItems[i].quantity;
  }
  const navigate = useNavigate();
  const handleOnClick = () => {
    navigate("/checkout");
  };
  const handleLogo = () => {
    navigate("/");
  };
  return (
    <header className="p-4 border-b-2  mb-8 w-full  bg-orange-600">
      <nav className="flex justify-around">
        <p
          className="text-orange-200 font-serif text-xl cursor-pointer"
          onClick={handleLogo}
        >
          E-Commerce Website
        </p>
        <div className="flex gap-2">
          <p className="text-orange-200 font-serif text-xl">Your Cart </p>
          <div className="relative flex cursor-pointer" onClick={handleOnClick}>
            <CiShoppingCart size={30} />
            <p className="text-xl font-serif text-orange-400">
              {items}
            </p>
          </div>
        </div>
      </nav>
    </header>
  );
};
