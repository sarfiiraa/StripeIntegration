import React, { useState, useEffect } from "react";
import { loadStripe } from "@stripe/stripe-js";
import { Elements } from "@stripe/react-stripe-js";
import Payment from "./components/Payment";
import CheckoutPage from "./pages/CheckoutPage";
import Home from "./pages/Home";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import axios from "axios";
import Success from "./components/Success";

const stripePromise = loadStripe("pk_test_51QXdi6CNe28bMH335TjKWUXZr8qzAwsFDxAJjBBlGl4aPpO1Rx7wK3ztcFbR3bpQpPPLkN27iMKuduc9KqbpTitG002hKqA8Jr");

function App() {
  const secret=localStorage.getItem("secret")
  const [clientSecret, setClientSecret] = useState(secret);

  // useEffect(() => {
  //   const fetchClientSecret = async () => {
  //     try {
  //       const res = await axios.post("http://localhost:3001/api/order/create", {
  //         purchasedItems: [], // You can adjust this based on your order data
  //         price: 100, // Example price
  //       });
  //       console.log(res)
  //       setClientSecret(res.data.clientSecret);
  //     } catch (error) {
  //       console.error("Error fetching clientSecret:", error);
  //     }
  //   };

  //   fetchClientSecret();
  // }, []);

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/checkout" element={<CheckoutPage />} />
        <Route
          path="/product/payment"
          element={
            
              <Elements stripe={stripePromise} options={{ clientSecret }}>
                <Payment />
              </Elements>
            
          }
          
        />
        <Route path="/success" element={<Success/>}/>
      </Routes>
    </Router>
  );
}

export default App;



// import Payment from "./components/Payment"
// import CheckoutPage from "./pages/CheckoutPage"
// import Home from "./pages/Home"
// import {BrowserRouter as Router , Routes, Route} from "react-router-dom"
// import {
//   PaymentElement,
//   Elements,
//   useStripe,
//   useElements,
// } from "@stripe/react-stripe-js";
// import { loadStripe } from "@stripe/stripe-js";

// function App() {

//   const stripePromise = loadStripe("pk_test_51QXdi6CNe28bMH335TjKWUXZr8qzAwsFDxAJjBBlGl4aPpO1Rx7wK3ztcFbR3bpQpPPLkN27iMKuduc9KqbpTitG002hKqA8Jr");
//   return (
//     <Router>
//          <Routes>
//           <Route path="/"  element={<Home/>} />
//           <Route path="/checkout"  element={<CheckoutPage/>} />
//           <Route path="/product/payment" element={
//             <Elements stripe={stripePromise}>
//               <Payment />
//             </Elements>
//             }/>
//          </Routes>
//     </Router>
//   )
// }


// export default App
