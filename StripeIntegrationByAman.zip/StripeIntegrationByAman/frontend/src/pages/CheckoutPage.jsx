import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { CartContext } from "../context/cart";
import { Navbar } from "../components/Navbar";

const CheckoutPage = () => {
  const { cartItems, getCartTotal, clearCart } = useContext(CartContext);
  const [email, setEmail] = useState("");
  const navigate = useNavigate();

  const handleProceedToPayment = async () => {
    if (!email) {
      alert("Please enter your email address to proceed.");
      return;
    }else{
      localStorage.setItem("email",email);
    }

    const purchasedItems = cartItems.map((item) => ({
      item: item.brand,
      quantity: item.quantity,
    }));

    try {
      const response = await axios.post("http://localhost:3001/api/order/create", {
        purchasedItems,
        price: getCartTotal(),
        email,
        paymentStatus:"pending",
      });

      const clientSecret = response.data.clientSecret;
      localStorage.setItem("secret",clientSecret)
      navigate("/product/payment", { state: { clientSecret } });
    } catch (error) {
      console.error("Error initializing payment:", error);
      alert("Failed to initialize payment. Please try again.");
    }
  };

  return (
    <main>
      <Navbar />
      <div className="flex-col flex items-center bg-white gap-8 p-10 text-black text-sm">
        <h1 className="text-2xl font-bold mt-6">Checkout</h1>
        <div className="flex flex-col gap-4">
          {cartItems.map((item) => (
            <div className="flex justify-between items-center" key={item.id}>
              <div className="flex gap-4">
                <img src={item.thumbnail} alt={item.title} className="rounded-md h-24" />
                <div className="flex flex-col">
                  <h1 className="text-lg font-bold">{item.title}</h1>
                  <p className="text-gray-600">{item.price}</p>
                </div>
                
              </div>
            </div>
          ))}
        </div>
        {/* ========================= */}

        {cartItems.length > 0 ? (
          <div className="flex  justify-between gap-8 items-center">
            <h1 className="text-lg font-bold">Total: ${getCartTotal()}</h1>
            <button
              className="px-4 py-2 bg-red-600 text-white text-xs font-bold uppercase 
              rounded hover:bg-gray-700 focus:outline-none focus:bg-gray-700"
              onClick={() => {
                clearCart();
              }}
            >
              Clear cart
            </button>
          </div>
        ): (
          <h1 className="text-lg font-bold">Your cart is empty</h1>
        )}
        {/* ========================= */}
        <div className="flex flex-col gap-4 w-1/2">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email"
            className="p-2 border rounded"
          />
          <button
            onClick={handleProceedToPayment}
            className="px-4 py-2 bg-green-600 text-white font-bold uppercase rounded hover:bg-green-700"
          >
            Proceed to Payment
          </button>
        </div>
      </div>
    </main>
  );
};

export default CheckoutPage;


// import React, { useContext } from "react";
// import { CartContext } from "../context/cart";
// import { Navbar } from "../components/Navbar";
// import { useNavigate } from "react-router-dom";


// const CheckoutPage = () => {
//   const { cartItems, addToCart, removeFromCart, clearCart, getCartTotal } =
//     useContext(CartContext);
//     const navigate = useNavigate()
//     const handlePayment = ()=>{
//       navigate("/product/payment")
//     }
//   return (
//     <main>
//       <Navbar />
//       <div className="flex-col flex items-center bg-white gap-8 p-10 text-black text-sm">
//         <h1 className="text-2xl font-bold mt-6">Cart</h1>
//         <div className="flex flex-col gap-4">
//           {cartItems.map((item) => (
//             <div className="flex justify-between items-center" key={item.id}>
//               <div className="flex gap-4">
//                 <img
//                   src={item.thumbnail}
//                   alt={item.title}
//                   className="rounded-md h-24"
//                 />
//                 <div className="flex flex-col">
//                   <h1 className="text-lg font-bold">{item.title}</h1>
//                   <p className="text-gray-600">{item.price}</p>
//                 </div>
//               </div>
              // <div className="flex gap-4">
              //   <button
              //     className="px-4 py-2 bg-orange-500 text-white text-xs font-bold uppercase rounded hover:bg-gray-700 focus:outline-none focus:bg-gray-700"
              //     onClick={() => {
              //       addToCart(item);
              //     }}
              //   >
              //     +
              //   </button>
              //   <p>{item.quantity}</p>
              //   <button
              //     className="px-4 py-2 bg-orange-500 text-white text-xs font-bold uppercase rounded hover:bg-gray-700 focus:outline-none focus:bg-gray-700"
              //     onClick={() => {
              //       removeFromCart(item);
              //     }}
              //   >
              //     -
              //   </button>
              // </div>
//             </div>
//           ))}
//         </div>
        // {cartItems.length > 0 ? (
        //   <div className="flex  justify-between gap-8 items-center">
        //     <h1 className="text-lg font-bold">Total: ${getCartTotal()}</h1>
        //     <button
        //       className="px-4 py-2 bg-red-600 text-white text-xs font-bold uppercase 
        //       rounded hover:bg-gray-700 focus:outline-none focus:bg-gray-700"
        //       onClick={() => {
        //         clearCart();
        //       }}
        //     >
        //       Clear cart
        //     </button>
//             <button
//             onClick={handlePayment}
//               className="px-4 py-2 bg-green-800 text-white text-xs 
//             font-bold uppercase rounded hover:bg-green-700 focus:outline-none focus:bg-green-700"
//             >
//               Checkout
//             </button>
//           </div>
        // ) : (
        //   <h1 className="text-lg font-bold">Your cart is empty</h1>
        // )}
//       </div>
//     </main>
//   );
// };

// export default CheckoutPage;
